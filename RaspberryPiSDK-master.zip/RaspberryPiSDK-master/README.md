# RaspberryPiSDK
科大讯飞在线语音听写（流式版）树莓派版本SDK
